/*! js-cookie v3.0.1 | MIT */
!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):(e=e||self,function(){var n=e.Cookies,o=e.Cookies=t();o.noConflict=function(){return e.Cookies=n,o}}())}(this,(function(){"use strict";function e(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var o in n)e[o]=n[o]}return e}return function t(n,o){function r(t,r,i){if("undefined"!=typeof document){"number"==typeof(i=e({},o,i)).expires&&(i.expires=new Date(Date.now()+864e5*i.expires)),i.expires&&(i.expires=i.expires.toUTCString()),t=encodeURIComponent(t).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape);var c="";for(var u in i)i[u]&&(c+="; "+u,!0!==i[u]&&(c+="="+i[u].split(";")[0]));return document.cookie=t+"="+n.write(r,t)+c}}return Object.create({set:r,get:function(e){if("undefined"!=typeof document&&(!arguments.length||e)){for(var t=document.cookie?document.cookie.split("; "):[],o={},r=0;r<t.length;r++){var i=t[r].split("="),c=i.slice(1).join("=");try{var u=decodeURIComponent(i[0]);if(o[u]=n.read(c,u),e===u)break}catch(e){}}return e?o[e]:o}},remove:function(t,n){r(t,"",e({},n,{expires:-1}))},withAttributes:function(n){return t(this.converter,e({},this.attributes,n))},withConverter:function(n){return t(e({},this.converter,n),this.attributes)}},{attributes:{value:Object.freeze(o)},converter:{value:Object.freeze(n)}})}({read:function(e){return'"'===e[0]&&(e=e.slice(1,-1)),e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent)},write:function(e){return encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,decodeURIComponent)}},{path:"/"})}));
;
(function ($, Drupal, drupalSettings, once) {

'use strict';

Drupal.quicktabs = Drupal.quicktabs || {};

Drupal.quicktabs.getQTName = function (el) {
  return el.attr('id').substring(el.attr('id').indexOf('-') + 1);
}

Drupal.behaviors.quicktabs = {
  attach: function (context, settings) {
    $(once('quicktabs-wrapper', 'div.quicktabs-wrapper', context)).each(function() {
      var el = $(this);
      Drupal.quicktabs.prepare(el);
    });
  }
}

// Setting up the inital behaviours
Drupal.quicktabs.prepare = function(el) {
  // el.id format: "quicktabs-$name"
  var qt_name = Drupal.quicktabs.getQTName(el);
  var $ul = $(el).find('ul.quicktabs-tabs:first');
  $ul.find('li a').each(function(i, element){
    element.myTabIndex = i;
    element.qt_name = qt_name;
    var tab = new Drupal.quicktabs.tab(element);
    var parent_li = $(element).parents('li').get(0);

    $(element).bind('click', {tab: tab}, Drupal.quicktabs.clickHandler);
    $(element).bind('keydown', {myTabIndex: i}, Drupal.quicktabs.keyDownHandler);
  });
}

Drupal.quicktabs.clickHandler = function(event) {
  var tab = event.data.tab;
  var element = this;
  // Set clicked tab to active.
  // Flip the aria-selected attribute.
  // The tabindex takes inactive tabs out of the tab pool,
  // they can be accessed by keyboard navigation.
  // This is a recommendation of the WAI-ARIA example:
  // https://www.w3.org/TR/wai-aria-practices-1.1/examples/tabs/tabs-2/tabs.html
  $(this).parents('li').siblings().removeClass('active');
  $(this).parents('li').siblings().attr('aria-selected', 'false');
  $(this).parents('li').siblings().attr('tabindex', '-1');
  $(this).parents('li').siblings().find('a').attr('tabindex', '-1');
  $(this).parents('li').addClass('active');
  $(this).parents('li').attr('aria-selected', 'true');
  $(this).attr('tabindex', '0');

  if ($(this).hasClass('use-ajax')) {
    $(this).addClass('quicktabs-loaded');
  }

  // Hide all tabpages.
  tab.container.children().addClass('quicktabs-hide');

  if (!tab.tabpage.hasClass("quicktabs-tabpage")) {
    tab = new Drupal.quicktabs.tab(element);
  }

  tab.tabpage.removeClass('quicktabs-hide');
  return false;
}

Drupal.quicktabs.keyDownHandler = function(event) {
  var tabIndex = event.data.myTabIndex;

  // This element should be a link element inside an
  // unordered list of tabs. Get all links in the list.
  var tabs = $(this).parent('li').parent("ul").find("li a");

  // Trigger the click and focus events for the individual tabs.
    switch (event.key) {
        case 'ArrowLeft':
        case 'ArrowUp':
            event.preventDefault();
            if (tabIndex <= 0) {
                tabs[tabs.length - 1].click();
                tabs[tabs.length - 1].focus();
            } else {
                tabs[tabIndex - 1].click();
                tabs[tabIndex - 1].focus();
            }
            break;
        case'ArrowRight':
        case'ArrowDown':
            event.preventDefault();
            if (tabIndex >= tabs.length - 1) {
                tabs[0].click();
                tabs[0].focus();
            } else {
                tabs[tabIndex + 1].click();
                tabs[tabIndex + 1].focus();
            }
    }
}

// Constructor for an individual tab
Drupal.quicktabs.tab = function (el) {
  this.element = el;
  this.tabIndex = el.myTabIndex;
  var qtKey = 'qt_' + el.qt_name;
  var i = 0;
  for (var i = 0; i < drupalSettings.quicktabs[qtKey].tabs.length; i++) {
    if (i == this.tabIndex) {
      this.tabObj = drupalSettings.quicktabs[qtKey].tabs[i];
      this.tabKey = typeof el.dataset.quicktabsTabIndex !== 'undefined' ? el.dataset.quicktabsTabIndex : i;
    }
  }
  this.tabpage_id = 'quicktabs-tabpage-' + el.qt_name + '-' + this.tabKey;
  this.container = $('#quicktabs-container-' + el.qt_name);
  this.tabpage = this.container.find('#' + this.tabpage_id);
}

// Enable tab memory.
// Relies on the jQuery Cookie plugin.
// @see http://plugins.jquery.com/cookie
  Drupal.behaviors.quicktabsmemory = {
    attach: function (context, settings) {
      // The .each() is in case there is more than one quicktab on a page.
      $(once('form-group', 'div.quicktabs-wrapper', context)).each(function () {
        var el = $(this);

        // el.id format: "quicktabs-$name"
        var qt_name = Drupal.quicktabs.getQTName(el);
        var $ul = $(el).find('ul.quicktabs-tabs:first');

        // Default cookie options.
        var cookieOptions = {path: '/'};
        var cookieName = 'Drupal-quicktabs-active-tab-id-' + qt_name;

        $ul.find('li a').each(function (i, element) {
          var $link = $(element);
          $link.data('myTabIndex', i);

          // Click the tab ID if a cookie exists.
          var $cookieValue = $.cookie(cookieName);
          if ($cookieValue !== '' && $link.data('myTabIndex') == $cookieValue) {
            $(element).click();
          }

          // Set the click handler for all tabs, this updates the cookie on
          // every tab click.
          $link.on('click', function () {
            var $linkdata = $(this);
            var tabIndex = $linkdata.data('myTabIndex');
            $.cookie(cookieName, tabIndex, cookieOptions);
          });
        });
      });
    }
  };


if (Drupal.Ajax) {

  /**
   * Handle an event that triggers an AJAX response.
   *
   * We unfortunately need to override this function, which originally comes
   * from misc/ajax.js, in order to be able to cache loaded tabs, i.e., once a
   * tab content has loaded it should not need to be loaded again.
   *
   * I have removed all comments that were in the original core function, so
   * that the only comments inside this function relate to the Quicktabs
   * modification of it.
   */
  Drupal.Ajax.prototype.eventResponse = function (element, event) {
    event.preventDefault();
    event.stopPropagation();

    // Create a synonym for this to reduce code confusion.
    var ajax = this;

    // Do not perform another Ajax command if one is already in progress.
    if (ajax.ajaxing) {
      return;
    }

    try {
      if (ajax.$form) {
        if (ajax.setClick) {
          element.form.clk = element;
        }

        ajax.$form.ajaxSubmit(ajax.options);
      }
      else {
        if (!$(element).hasClass('quicktabs-loaded')) {
          ajax.beforeSerialize(ajax.element, ajax.options);
          $.ajax(ajax.options);
        }
      }
    }
    catch (e) {
      ajax.ajaxing = false;
      window.alert('An error occurred while attempting to process ' + ajax.options.url + ': ' + e.message);
    }
  };
}

})(jQuery, Drupal, drupalSettings, once);
;
